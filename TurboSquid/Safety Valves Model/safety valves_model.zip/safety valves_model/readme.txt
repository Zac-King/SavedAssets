 
************************************************
safety valves spring loaded
By BARAKA_DESIGN
Email:barakades@yahoo.com
Copyright 2004 BARAKA_DESIGN
************************************************
VALVE PACK 2/14
2-safety valves spring loaded
This model is the part of the Valve Packs Collection that contains 14 different armatures

Applications
Water,steam,gas,compressed air and other neutral mediums.

Very high detailed and precision mechanical pipeline element model
based on original CAD drawing.
(inside and outside)

zip file includes
Autocad drawings file,
Assembled model,
Disassembled model,
and cut away model.

All parts seperately modeled, ready to animation.
(see valve.avi) 
Can use for training applications,
presentation, ilustration etc.


FILE LIST:
Archive (safety valves_model.zip) contains 6 files below

*TEXTURES*
REFMAP.tga

*Models*
safety valves spring loaded_assembled.max
safety valves spring loaded_disassembled.max
safety valves spring loaded_cut_away.max

safety valves spring loaded_cad_drawing.DWG
Readme.txt

 
unzip the files in any folder to open it.
All files must be in same folder.

*************************************************************
Copyright Statement

All object meshes and cad drawing were made by BARAKA_DESIGN
*************************************************************


Thank you for your interest in this model
BARAKA_DESIGN

august 2004
