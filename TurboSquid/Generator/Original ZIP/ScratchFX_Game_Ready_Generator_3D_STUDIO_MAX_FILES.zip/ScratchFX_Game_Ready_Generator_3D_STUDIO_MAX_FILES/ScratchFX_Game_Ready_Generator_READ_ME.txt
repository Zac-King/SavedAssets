

2015

ScratchFX  GAME READY GENERATOR

Geometry: POLYGONS
Polygons: 1186
Vertices: 1345
Tris: 2016


Description

ScratchFX Game ready Generator.Displayed in the Marmoset game engine.
Modeled to scale measuring approximately 165cm high, 238cm wide, 106cm deep. 
Optimized game mesh to 2016 Tris. The model has mirrored UVs for that extra texture resolution.
Select the OBJ file and place into your game engine and the model will be good to go.

Textures include a Diffuse, Normal, Specular and I have included the PSD file with all layers so you can edit the colours if you wish.There is also the Ambient Occlusion layer in the PSD file.

The Maya Scene file can be rendered through the ScratchFX_Camera.
This scene file has been rendered with mental ray so make sure to enable mental ray in your plugins window.

The 3ds Max 2012 Scene file is not setup to be rendered.


----------------------------------------------------------------------------------------------------------------------

File Formats:

MAYA 2013
ScratchFX_Game_Ready_Generator_Scene.MB
ScratchFX_Game_Ready_Generator_Scene.ASCII


3DS MAX 2012
ScratchFX_Game_Ready_Generator_3D_Studio_Max_2012

FBX
(FBX Plug in version 2013.1 Release)
ScratchFX_Game_Ready_Generator_FBX_2012
ScratchFX_Game_Ready_Generator_FBX_2013

OBJ
ScratchFX_Generator_Game_Mesh_OBJ

Textures
PSD - All Textures + Abient Occlusion map
2048 (2k) Diffuse
2048 (2k) Normal 
2048 (2k) Specular

